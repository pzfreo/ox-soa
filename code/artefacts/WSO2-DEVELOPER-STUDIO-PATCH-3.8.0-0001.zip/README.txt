Patch ID         : WSO2-DEVELOPER-STUDIO-PATCH-3.8.0-0001
Applies To       : WSO2 Developer-Studio 3.8.0
Associated JIRAs : https://wso2.org/jira/browse/TOOLS-3286
		   https://wso2.org/jira/browse/TOOLS-3267


DESCRIPTION
-----------

Solves two issues in ESB Sequence Editor and Task Editor.
Issue 1 : ESB Sequence Editor loses endpoint tags.
Issue 2 : Task Editor time interval being multiplied by 1000.

INSTALLATION INSTRUCTIONS
-------------------------

(i)    Close eclipse if it is already started.
(ii)   Copy all the bundles that included in patch0001 to <eclipse-home-directory>/plugins directory.
(iii)  Restart Eclipse with -clean option from command line
	   windows - eclipse.exe -clean
	   linux/Mac OS X   - ./eclipse -clean
	(there after, you can start eclipse in the normal way)


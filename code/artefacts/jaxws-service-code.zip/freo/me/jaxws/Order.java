package freo.me.jaxws;

public class Order {
	
	private String poNumber;
	private String lineItem;
	private String quantity;
	private String date;
	private String customerNumber;

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getLineItem() {
		return lineItem;
	}

	public void setLineItem(String lineitem) {
		this.lineItem = lineitem;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}


}

package freo.me.jaxws;

public interface OrderService {

	public abstract String createEntry(Order order);

	public abstract String[] getOrders();

	public abstract Order getOrder(String id) throws NotFoundException;

}
package freo.me.jaxws;

import java.util.concurrent.ConcurrentMap;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class OrderServiceImpl implements OrderService {
	private static OrderService instance = null;
	private static ConcurrentMap<String, Order> orders = new ConcurrentHashMap<String, Order>();

	public static OrderService getInstance() {
		if (instance == null) {
			synchronized (OrderServiceImpl.class) {
				if (instance == null) {
					instance = new OrderServiceImpl();
				}
			}
		}
		return instance;
	}

	public OrderServiceImpl() {
		String uuid = UUID.randomUUID().toString();
		Order entry = new Order();
		entry.setCustomerNumber("FREO001");
		entry.setDate("5/5/12");
		entry.setLineItem("00001");
		entry.setPoNumber("OXSOA001");
		entry.setQuantity("5");
		orders.put(uuid, entry);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see freo.me.jaxws.OrderService#createEntry(freo.me.jaxws.Order)
	 */
	@Override
	public String createEntry(Order order) {

		String uuid = UUID.randomUUID().toString();
		Order entryPut = orders.putIfAbsent(uuid, order);
		if (entryPut != null) // problem - already an entry with that UUID!?
		{
			throw new RuntimeException("Serious UUID problem");
		}

		return uuid;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see freo.me.jaxws.OrderService#getOrders()
	 */
	@Override
	public String[] getOrders() {

		return orders.keySet().toArray(new String[0]);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see freo.me.jaxws.OrderService#getOrder(java.lang.String)
	 */
	@Override
	public Order getOrder(String id) throws NotFoundException {
		if (!orders.containsKey(id))
			throw new NotFoundException();

		return orders.get(id);

	}

}

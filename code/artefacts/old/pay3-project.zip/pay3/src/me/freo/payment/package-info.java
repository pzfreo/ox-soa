@javax.xml.bind.annotation.XmlSchema(namespace = "http://freo.me/payment/")
package me.freo.payment;

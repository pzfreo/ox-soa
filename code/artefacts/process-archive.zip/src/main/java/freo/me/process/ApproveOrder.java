package freo.me.process;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("Order Approval Process")
public class ApproveOrder extends ServletProcessApplication {
  // empty implementation
}

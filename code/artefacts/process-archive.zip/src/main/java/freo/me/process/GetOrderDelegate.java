package freo.me.process;

import java.util.logging.Logger;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.json.JSONObject;

public class GetOrderDelegate implements JavaDelegate {
	private final static Logger LOGGER = Logger.getLogger("APPROVAL-REQUESTS");

	public void execute(DelegateExecution de) throws Exception {

		String id = (String) de.getVariable("id");
		LOGGER.info("Processing request by '" + de.getVariable("id"));

		Client client = ClientBuilder.newClient();
		WebTarget target = client.target("http://localhost:80")
				.path("purchase").path(id);

		Response response = target.request(MediaType.APPLICATION_JSON).get();
		if (response.getStatus() == 200) {

			JSONObject json = new JSONObject(response.readEntity(String.class));
			de.setVariable("lineItem", json.get("lineItem"));
			de.setVariable("date", json.get("date"));
			de.setVariable("quantity", json.get("quantity"));
			de.setVariable("customerNumber", json.get("customerNumber"));
			de.setVariable("poNumber", json.get("poNumber"));

		} else {
			throw new BpmnError("ID NOT FOUND");
		}

	}

}

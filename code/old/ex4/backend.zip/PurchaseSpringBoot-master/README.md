# PurchaseSpringBoot
A simple JAX-RS SpringBoot app

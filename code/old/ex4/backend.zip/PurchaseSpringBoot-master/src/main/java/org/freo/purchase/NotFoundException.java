package org.freo.purchase;

public class NotFoundException extends Exception {

	private static final long serialVersionUID = 4371015715418120962L;

}
